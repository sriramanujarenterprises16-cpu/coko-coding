# COKO Coding

A neon-themed beginner coding website built as a single static `index.html` file. It is suitable for GitHub Pages.

## Features
- HTML, CSS and JavaScript editor with live preview and Run button
- Python editor using Pyodide in the browser (first run requires internet)
- Beginner lessons and sample projects
- Project gallery
- Local student display profile
- Save/open/delete projects in this browser
- Beginner quiz and printable certificate

## Run on Windows
1. Download and extract `COKO-Coding.zip`.
2. Open the `coko-coding` folder.
3. Double-click `index.html` to open it in Chrome or Edge.
4. For Python execution, stay connected to the internet while Pyodide loads.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new public repository, for example `coko-coding`.
2. Upload `index.html` to the repository root (the top level, not inside another folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish and open the website URL shown on that page.

## Important: login and saving limitations
GitHub Pages only hosts static files; it does not run a private server or database. This demo's profile and projects are stored in `localStorage` in the current browser. They do not sync between devices, and clearing browser data can delete them. The profile is not secure authentication; do not collect real passwords or sensitive student information.

For real student accounts and cloud-synced projects, connect a backend/auth service such as Firebase Authentication + Firestore or Supabase Auth + Database. Configure access rules so each student can read/write only their own data. Never put private service-role keys in frontend code. For a school project demo, this local version works without a backend.

## Safety note
The code editor executes the user's code in a sandboxed iframe. Do not use this as a public multi-user code execution service without stronger isolation and abuse protections.
